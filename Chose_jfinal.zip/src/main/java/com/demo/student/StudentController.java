package com.demo.student;


import com.jfinal.aop.Inject;
import com.jfinal.core.Controller;
import com.jfinal.core.Path;


@Path("/student")
public class StudentController extends Controller {
	
	@Inject
	StudentService service;
	
	public void index() {

		setAttr("studentPage", service.paginate(getParaToInt(0, 1), 10));
		System.out.println(service.paginate(getParaToInt(0, 1), 10));
		render("student.html");
	}
	
	public void add() {
	}
	

	public void save() {

		String name = getPara("student.name");
		String sex = getPara("student.sex");
		String num = getPara("student.num");
		String cl = getPara("student.cl");
		String age = getPara("student.age");

		new Student().set("name", name).set("sex", sex).set("num", num).set("cl", cl).set("age", age)
				.save();

		redirect("/student");
	}
	
	public void edit() {
		setAttr("student", service.findById(getParaToInt()));
	}
	

	public void update() {

		String id = get("student.id");
		String name = getPara("student.name");
		String sex = getPara("student.sex");
		String num = getPara("student.num");
		String cl = getPara("student.cl");
		String age = getPara("student.age");

		System.out.println("********************************");
		System.out.println(id);
		System.out.println("********************************");

		Student.dao.findById(id).set("name", name).set("sex", sex).set("num", num).set("cl", cl).set("age", age)
				.update();

		redirect("/student");
	}
	
	public void delete() {
		service.deleteById(getParaToInt());
		redirect("/student");
	}
}


